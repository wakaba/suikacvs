function jumpTo(url)
{
  window.location = url;
}